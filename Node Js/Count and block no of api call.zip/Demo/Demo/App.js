
const express = require('express');

const app = express();
app.use(express.json())
app.use(express.urlencoded({ extended: true }))
app.use(require('cors')())
let buffer = []
const countUser = (req, res, next) => {
  buffer.push({ time: Date.now(), route: req.headers?.referer })
  let count = buffer.filter(a => a.time > new Date(Date.now() - 1000 * 60) && a.route === req.headers?.referer).length
  console.log(req.headers.referer)
  const fullUrl = req.protocol + '://' + req.hostname + req.originalUrl
  req.body = {data: {...req.body}, ...buffer}
  if (count > 10) {
    res.status(403).send('Request Timout')
  } else {
    next()
  }
}

app.use(countUser)

app.listen(8000, () => {
  console.log('Listening on port 8000')
});

app.post('/', (req, res) => {
  // console.log(req.route.path)
  res.status(200).json(req.body)
})

