import axios from 'axios';
import { useEffect, useRef, useState } from 'react';
import './App.css';

function App() {
  const [data, setData] = useState()
  const ref = useRef(false)
  useEffect(() => {
    if(ref.current) return
    axios.post('http://127.0.0.1:8000', {'username': 'admin'})
      .then(res => {
        setData(res.data)
        console.log(res)
      })
      .catch(err => console.log(err))
    ref.current = true
  }, [])
  return (
    <div>
      <pre>
        {JSON.stringify(data, null, 2)}
      </pre>
    </div>
  );
}

export default App;
